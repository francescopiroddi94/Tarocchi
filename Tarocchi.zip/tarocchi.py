# Copyright (C) 2025 Francesco Piroddi
# Questo programma è distribuito con la licenza GNU General Public License v3.0
# Leggi la licenza completa alla fine di questo file o visita https://www.gnu.org/licenses/gpl-3.0.html

import random

# Dizionario delle carte degli Arcani Maggiori
arcani_maggiori = {
    0: {"nome": "Il Matto", "descrizione": "Rappresenta l'inizio di un viaggio, l'innocenza, la spontaneità e la libertà."},
    1: {"nome": "Il Mago", "descrizione": "Simboleggia il potere della volontà, l'iniziativa e l'abilità di usare le risorse."},
    2: {"nome": "La Papessa", "descrizione": "Rappresenta la saggezza interiore, l'intuizione e il mistero."},
    3: {"nome": "L'Imperatrice", "descrizione": "Simbolo di fertilità, creatività, abbondanza e maternità."},
    4: {"nome": "L'Imperatore", "descrizione": "Simboleggia autorità, stabilità, protezione e leadership."},
    5: {"nome": "Il Papa", "descrizione": "Rappresenta la spiritualità, la guida morale e i valori tradizionali."},
    6: {"nome": "Gli Amanti", "descrizione": "Rappresenta le scelte, le relazioni, l'armonia e l'unione."},
    7: {"nome": "Il Carro", "descrizione": "Simboleggia il successo ottenuto con determinazione e controllo."},
    8: {"nome": "La Giustizia", "descrizione": "Rappresenta l'equilibrio, la verità, la legalità e le scelte morali."},
    9: {"nome": "L'Eremita", "descrizione": "Simboleggia la ricerca interiore, la solitudine e la saggezza acquisita."},
    10: {"nome": "La Ruota della Fortuna", "descrizione": "Rappresenta i cicli della vita, il destino e i cambiamenti inevitabili."},
    11: {"nome": "La Forza", "descrizione": "Simboleggia il coraggio, la pazienza, la determinazione e il controllo delle emozioni."},
    12: {"nome": "L'Appeso", "descrizione": "Rappresenta il sacrificio, l'attesa e una nuova prospettiva."},
    13: {"nome": "La Morte", "descrizione": "Simboleggia la fine di un ciclo, la trasformazione e la rinascita."},
    14: {"nome": "La Temperanza", "descrizione": "Simboleggia l'armonia, l'equilibrio e la moderazione."},
    15: {"nome": "Il Diavolo", "descrizione": "Rappresenta la tentazione, le dipendenze e la consapevolezza dei propri limiti."},
    16: {"nome": "La Torre", "descrizione": "Simboleggia la rottura improvvisa, il cambiamento drammatico e la liberazione."},
    17: {"nome": "La Stella", "descrizione": "Simboleggia la speranza, la guarigione e la fiducia nel futuro."},
    18: {"nome": "La Luna", "descrizione": "Rappresenta inganno, incertezze, sogni e paure inconsce."},
    19: {"nome": "Il Sole", "descrizione": "Simboleggia la gioia, il successo, la chiarezza e la vitalità."},
    20: {"nome": "Il Giudizio", "descrizione": "Rappresenta la riflessione finale, la trasformazione e la rinascita."},
    21: {"nome": "Il Mondo", "descrizione": "Simboleggia il completamento del ciclo, l'armonia e la realizzazione."}
}

# Funzione per estrarre una carta casuale
def estrai_carta():
    carta_numero = random.randint(0, 21)
    carta = arcani_maggiori[carta_numero]
    return carta

# Funzione principale per mostrare la lettura
def lettura_tarocchi():
    print("Benvenuto nel mondo dei Tarocchi!")
    input("Premi invio per estrarre una carta...")
    
    carta = estrai_carta()
    
    print("\nLa carta estratta è:", carta["nome"])
    print("Descrizione:", carta["descrizione"])

# Avvio del programma
if __name__ == "__main__":
    lettura_tarocchi()

# Licenza GPL-3.0
#
# Questo programma è software libero: puoi ridistribuirlo e/o modificarlo
# sotto i termini della GNU General Public License, versione 3, come
# pubblicata dalla Free Software Foundation.
#
# Questo programma è distribuito nella speranza che possa essere utile,
# ma SENZA ALCUNA GARANZIA; senza neppure la garanzia implicita di
# COMMERCIABILITÀ o IDONEITÀ AD UNO SCOPO PARTICOLARE. Vedi la
# GNU General Public License per i dettagli.
#
# Puoi ricevere una copia della GNU General Public License alla Free
# Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
#
# La licenza completa è disponibile su: https://www.gnu.org/licenses/gpl-3.0.html
